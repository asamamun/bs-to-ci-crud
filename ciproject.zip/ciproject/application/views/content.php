<hr>
<div class="well">
<?php echo $content; ?>
</div>
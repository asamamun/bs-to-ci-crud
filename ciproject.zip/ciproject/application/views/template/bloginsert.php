<h1  style="margin-top:80px"><?php echo $m; ?></h1>
<h3><?php //echo APPPATH; ?></h3>
<p>xss_clean is no longer part of form validation in Codeingitore 3</p>
<div class="well">
<?php echo validation_errors('<div class="error">', '</div>'); ?>
</div>
<form method="POST" enctype="multipart/form-data" action="<?php echo base_url();?>blog/<?php 
if(isset($action)) echo $action;
?>">
<input type="hidden" value="<?php 
if(isset($row[0]->blogid)) echo $row[0]->blogid;
?>" name="blogid"/>
Blog Title: <br />
<input type="text" name="btitle" value="<?php 
if(isset($row[0]->blogtitle)) echo $row[0]->blogtitle;
else echo set_value('btitle');
?>" /><?php echo form_error('btitle'); ?><br />
Blog Description<br />
<textarea name="bcontent" rows="15" cols="80"><?php 
if(isset($row[0]->blogcontent)) echo $row[0]->blogcontent;
else echo set_value('bcontent');
?></textarea>
<?php echo form_error('bcontent'); ?>
<hr>
File:<br />
<input name="file" type="file" /><br />
<input type="submit" name="bloginsertbtn" value="<?php 
if(isset($action)) echo ucwords($action);
?>" />
</form>
<!--
<?php echo form_open_multipart('upload/do_upload');?>
File:<br />
<input name="file" type="file" /><br />
<input type="submit" name="submit" value="Upload" />
<?php echo form_close(); ?>
-->
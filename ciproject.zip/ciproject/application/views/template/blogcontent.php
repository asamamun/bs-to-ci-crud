<div class="container" style="margin-top:80px">
<?php
//var_dump($contents);
foreach($contents as $content){
	echo "<div class='well'><a href='".site_url()."blog/blogdetails/".$content->blogid."'>";
	echo "<h3 class='bg-primary'>".$content->blogtitle."</h3></a>";
	$desc = (strlen($content->blogcontent)<300)?$content->blogcontent:substr($content->blogcontent,0,strpos($content->blogcontent, " " ,300))."<a class='btn btn-default' href='blog/blogdetails/".$content->blogid."'>Details</a>";
	echo "<div class='row'><div class='col-sm-8'>";
	echo "<p class=''>".$desc;
	echo "<a class='btn btn-default' href='".site_url()."blog/blogedit/".$content->blogid."'>Edit</a>";
	echo "<a class='btn btn-default' href='".site_url()."blog/blogdelete/".$content->blogid."'>Delete</a></p></div>";
	$imagefile = base_url()."uploads/".$content->blogid . ".png";
	$notfoundimage = base_url()."uploads/1.jpg";
	if(file_exists("uploads/".$content->blogid . ".png")){
	echo "<div class='col-sm-4'><img src='".$imagefile."' class='img-responsive'></div>";
}
else echo "<div class='col-sm-4'><img src='".$notfoundimage."' class='img-responsive'></div>";
	
	echo "</div></div>";	
	}
echo "<hr>";
echo $links;	


echo "</div>";
<div class="container" style="margin-top:80px">
<?php
//var_dump($contents);

	echo "<div class='well'>";
	//echo "<a class='btn btn-default' href='blog/index'>BACK</a>";
	echo anchor("blog","back",'class="btn btn-default"');
	echo "<h3 class='bg-primary'>".$contents[0]->blogtitle."</h3>";
	echo "<p class=''>".$contents[0]->blogcontent."</p>";
	echo "<em>Published on ".$contents[0]->created."</em>";
	
	echo "</div>";	
	
echo "</div>";
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mysession extends CI_Controller {
function __construct(){
	parent::__construct();
	//load session library
	$this->load->library('session');
	
	}
function index(){
echo '<h1><pre>Accessing session metadata
In previous CodeIgniter versions, 
the session data array included 4 items by default: 
‘session_id’, ‘ip_address’, ‘user_agent’, ‘last_activity’.

This was due to the specifics of how sessions worked, 
but is now no longer necessary with our new implementation. 
However, it may happen that your application relied on these values, 
so here are alternative methods of accessing them:

session_id: session_id()
ip_address: $_SERVER[\'REMOTE_ADDR\']
user_agent: $this->input->user_agent() (unused by sessions)
last_activity: Depends on the storage, no straightforward way. 
Sorry!</pre></h1>';	
echo "<h1>Your controller name should not be session</h1>";
echo "<h3>The Session class relies on the Encryption class, so you must have Mcrypt extension installed</h3>";
$data = array(
'username' => 'idbbisew',
'email' => 'idbbisew@idbbisew.com',
'logged_in' => TRUE
);
$this->session->set_userdata($data);
$this->session->tspname = "pttc";

echo "value in session added";
echo "<hr>Four default values stored in session. These are:";
echo "<hr>";
echo "Session ID:" . $this->session->session_id;
echo "<hr>";
echo "IP:" . $this->session->ip_address;
echo "<hr>";
echo "OS and Browser info : " . $this->session->user_agent;
echo "<hr>";
echo "Last used: " . $this->session->last_activity;
}


function delemail(){
	$this->session->unset_userdata('email');	
}
function show_session_val(){
echo $this->session->username;
echo "<hr>";
echo "Email:" . $this->session->userdata('email');
echo "<hr>";
echo "Email:" . $this->session->email;
echo "<hr>";
echo $this->session->userdata('logged_in');
echo "<hr>";
echo $this->session->tspname;
}
function show(){
	var_dump($this->session->all_userdata());
	
}
function set_flash_data(){
$this->session->set_flashdata('message', 'Data added');
$this->session->set_flashdata('student', 'misti');
$this->session->set_userdata('mytsp','PTTC');
}
function get_flash_data(){
echo $this->session->flashdata('message');
echo $this->session->flashdata('student');
$this->session->keep_flashdata('message');
echo "<hr>";
echo $this->session->userdata('mytsp');
}
function showmessage(){
	echo $this->session->flashdata('message');
	echo "<hr>";
	echo $this->session->flashdata('student');
	
}
function destroy(){
	$this->session->sess_destroy();	
}
}
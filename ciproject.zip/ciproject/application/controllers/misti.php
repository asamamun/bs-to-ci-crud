<?php
class Misti extends CI_Controller{
	function Misti()
	{	
	parent::__construct();
	$this->load->helper("wpsiarray_helper");
	
	}
	
	public function index(){
		echo "hello Round 30. How r u? i am fine. thank you.";		
	}
public function mytsp(){
	echo "<h1>I am from PTTC</h1>";	
}
public function welcome(){
	$this->load->view("header");
	$this->load->view("welcome_message");
	$this->load->view("footer");	
}
public function v($em){
	if(valid_email($em)) echo "<h1>Email $em valid</h1>";
	else echo "<h1>Email $em invalid</h1>";
	echo "<hr>";
	echo "Your username: " . username($em);
	
}
function showbase(){echo base_url();}
function names(){
	$names = string_to_array("a,b,c,e,aa,bb,cc,dd");
	var_dump($names);
	
	
}	
}

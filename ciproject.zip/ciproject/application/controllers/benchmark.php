<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Benchmark extends CI_Controller {
	function __construct(){
	parent::__construct();
	$this->output->enable_profiler(TRUE);
	}

	public function index()
	{
		$this->benchmark->mark('start');
		$this->load->helper('commonfx');//commonfx_helper.php
		$this->load->library('session');
		$this->benchmark->mark('loadlib');
		//$this->load->library('email');		
		//$this->load->view('welcome_message');
		$this->load->view('header', array('title'=>'home page'));
		$this->benchmark->mark('loadheader');
		//$this->session->setname();
		$data['datenow'] = showdate();
		$data['username'] = $this->email->getbaseurl();
		//$data['username'] = $this->email->showemailadd();
		//$data['username'] = $this->session->get_name();
		$this->load->view('round26View',$data);
		$this->benchmark->mark('loadview');
		$this->load->view('footer');
		$this->benchmark->mark('end');
		echo $this->benchmark->elapsed_time('loadheader', 'loadview');
	}
	public function hi($val)
	{
		//$this->load->view('welcome_message');
		//$this->load->view('round26View');
		echo "hi from hi ".$val;
	}
	
}

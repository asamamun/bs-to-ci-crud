<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Image extends CI_Controller {

	public function __construct(){		
		parent::__construct();
		$config['image_library'] = 'gd2';
$config['source_image'] = APPPATH . 'images/1 (3).jpg';
$config['new_image'] = APPPATH . 'images/1 (1) Copy.jpg';
$config['create_thumb'] = TRUE;
$config['maintain_ratio'] = TRUE;
$config['width'] = 800;
$config['height'] = 500;
$this->load->library('image_lib', $config);
	}
	public function index()
	{
			
$this->image_lib->resize();
		
		
	}
	public function crop(){
	$config['image_library'] = 'gd2';
$config['source_image'] = APPPATH . 'images/1 (1) Copy_thumb.jpg';
$config['x_axis'] = '200';
$config['y_axis'] = '150';
$config['width'] = 200;
$config['height'] = 100;
$this->image_lib->initialize($config);
		
		if ( ! $this->image_lib->crop())
{
echo $this->image_lib->display_errors();
}		
	}
	public function rotate(){
		$this->image_lib->clear();
		$config['image_library'] = 'gd2';
		$config['source_image'] = APPPATH . 'images/IMG_20161219_161749.jpg';
		$config['rotation_angle'] = 'hor';
		$this->image_lib->initialize($config);
		if ( ! $this->image_lib->rotate())
{
echo $this->image_lib->display_errors();
}
		
		
	}
	
	
}

<?php
class Main extends CI_Controller{
	function Main()
	{
	parent::__construct();
	
	}
	
	
	public function index(){		
		$contentdata['jumbo_title'] = "PTTC WPSI is an app landing page that will help you beautifully showcase your new mobile app, or anything else!";
		$m = '<li>
                        <a class="page-scroll" href="#download">Download</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#features">Features</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>';
		$this->load->view("template/header");			
		//echo base_url();
		$data['navstyle'] = "default";
		$data['menu'] = $m;
		
		$this->load->view("template/navbar",$data);		
		$this->load->view("template/content", $contentdata);
		$this->load->view("template/footer");		
	}
}

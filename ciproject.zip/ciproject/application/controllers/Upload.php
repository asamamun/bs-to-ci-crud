<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload extends CI_Controller {
public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
				$this->load->helper(array('form','commonfx'));
        }
public function index(){
//$this->load->view("uploadForm");
 $this->load->view('uploadForm', array('error' => ' ' ));
}
 public function do_upload()
        {
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 8000;
                $config['max_width']            = 5024;
                $config['max_height']           = 5068;
				$new_name = time().$_FILES["userfile"]['name'];
				$config['file_name'] = $new_name;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('uploadForm', $error);
                }
                else
                {
                        echo resizeimage($this->upload->data('full_path'));
						$data = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_success', $data);
                }
        }		
}
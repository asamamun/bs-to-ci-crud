<?php
class Blog extends CI_Controller{
	function Blog()
	{
	parent::__construct();
	$this->load->database();
	$this->load->model("blog_model","blog");
	$this->load->helper(array("form","file","security"));	
	$this->load->library(array('pagination', 'form_validation'));
	
	/*$config['image_library'] = 'gd2';
	$config['source_image'] = APPPATH . 'uploads/myimage.jpg';
	$config['new_image'] = APPPATH . 'uploads/mynewimage.jpg';
	$config['create_thumb'] = TRUE;
	$config['maintain_ratio'] = TRUE;
	$config['width'] = 75;
	$config['height'] = 50;
	$this->load->library('image_lib', $config);*/
	
	}
	
	public function index($start=0){
		$per_page = 10;
		$config['base_url'] = site_url() . '/blog/index/';
		
		$config['total_rows'] = $this->blog->totalblogs();
		$config['per_page'] = $per_page;
		$config['num_links'] = 2;
		$config['first_link'] = 'Start';
		$config['first_tag_open'] = "<span class='btn btn-success'>";
		$config['first_tag_close'] = "</span>";
		$config['last_link'] = 'End';
		$config['last_tag_open'] = "<span class='btn btn-success'>";
		$config['last_tag_close'] = "</span>";
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = "<span class='btn btn-success'>";
		$config['next_tag_close'] = "</span>";
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = "<span class='btn btn-success'>";
		$config['prev_tag_close'] = "</span>";
		$config['cur_tag_open'] = "<span class='btn btn-info'>";
		$config['cur_tag_close'] = "</span>";
		$config['num_tag_open'] = "<span class='btn btn-success'>";
		$config['num_tag_close'] = "</span>";
		
		
		$this->pagination->initialize($config);
		
		$this->load->view("template/header");
		$data['navstyle'] = "inverse";
		$this->load->view("template/navbar",$data);
		$blogdata['contents'] = $this->blog->get_last_ten_entries($start,$per_page);
		$blogdata['links'] = $this->pagination->create_links();
		$this->load->view("template/blogcontent",$blogdata);
		$this->load->view("template/footer");		
	}
	public function blogdetails($id){
		
		$this->load->view("template/header");
		$data['navstyle'] = "inverse";
		$this->load->view("template/navbar",$data);
		
		$blogdata['contents'] = $this->blog->details($id);
		$this->load->view("template/blogdetails",$blogdata);
		$this->load->view("template/footer");		
		}
	public function check_length($v){
		if(strlen($v)<20){
		$this->form_validation->set_message('check_length', 'The {field} field should be at least 20 characters');	
			return false;}
		else return true;
		
	}	
	public function insert(){
		//rules
		$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
		$this->form_validation->set_rules('btitle', 'Blog Title', 'required|xss_clean|callback_check_length');
		$this->form_validation->set_rules('bcontent', 'Blog Content', 'required|xss_clean|min_length[50]');		
		//rules
		
		
		if($this->form_validation->run() == FALSE){
			$data['m'] = "Blog Create Form";
		}
		else{		
		if($this->input->post("bloginsertbtn")){
		$data = array("blogtitle"=>$this->input->post("btitle"),
		"blogcontent"=>$this->input->post("bcontent"),
		"published"=>1);
		
		$id = $this->blog->add($data);
		$config['upload_path'] = APPPATH . '../uploads/';
		$config['allowed_types']  = 'gif|jpg|png|jpeg';
		$config['max_size'] = '96144';
		$config['file_name'] = $id.".png";
		//move_uploaded_file($_FILES['file']['tmp_name'],APPPATH . 'uploads/'.$id.".png");
		$this->load->library('upload', $config);
		
		//$this->upload->file_name = $id.".png";
		$this->upload->do_upload("file");
		//echo "<h1>Errors: " . $this->upload->display_errors()."</h1>";
		//$this->upload->data("file");		
		//$this->upload->display_errors('<p>', '</p>');
		$data['m'] = "data inserted ".$this->upload->file_name . " and id: " . $id ;
		}
		}
		$this->load->view("template/header");
		$data['navstyle'] = "inverse";
		$data['action'] = "insert";
		$this->load->view("template/navbar",$data);
		$this->load->view("template/bloginsert",$data);
		$this->load->view("template/footer");
		
	}
	public function blogdelete($id){
		$this->blog->delete($id);
		redirect(base_url().'blog', 'refresh');
		}		
	
	public function blogedit($id){
		$record = $this->blog->details($id);
		$this->load->view("template/header");
		$data['navstyle'] = "inverse";
		$this->load->view("template/navbar",$data);
		$rec['m'] = "Edit Article";
		$rec['row'] = $record;
		$rec['action'] = "update";
		$this->load->view("template/bloginsert",$rec);
		$this->load->view("template/footer");		
		}
	public function update(){
		$data = array(
		"blogid"=>$this->input->post("blogid"),
		"blogtitle"=>$this->input->post("btitle"),
		"blogcontent"=>$this->input->post("bcontent"),
		);
		$this->blog->update($data);
		redirect(base_url().'blog/blogdetails/'.$this->input->post("blogid"), 'refresh');
		}	
	

}

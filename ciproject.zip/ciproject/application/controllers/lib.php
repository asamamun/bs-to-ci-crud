<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Lib extends CI_Controller{
	
	function Lib()
	{
	parent::__construct();
	$this->load->database();
	$this->load->model("blog_model","blog");	
	}
	public function index(){
		$this->output->enable_profiler(TRUE);
		$this->benchmark->mark('start');
		//$this->benchmark->mark('loadlib');
		//$this->load->library('email');		
		//$this->load->view('welcome_message');
		$this->load->view("template/header");
		$data['navstyle'] = "inverse";
		$this->load->view("template/navbar",$data);
		$this->benchmark->mark('loadheader');
		$blogdata['contents'] = $this->blog->get_last_ten_entries(0,5);
		$this->load->view("template/blogcontent",$blogdata);
		$this->benchmark->mark('loadview');
		$this->load->view("template/footer");
		$this->benchmark->mark('end');
		//$data['content'] =  "Header load time: " . $this->benchmark->elapsed_time('start', 'loadheader'). "<br>"."View load time: " . $this->benchmark->elapsed_time('loadheader', 'loadview'). "<br>"."Total load time: " . $this->benchmark->elapsed_time('start', 'end'). "<br>Total execution time: " . $this->benchmark->elapsed_time()."<br>";
		$data['content'] = $this->input->ip_address();
		$this->load->view("content",$data);
		
	}
}
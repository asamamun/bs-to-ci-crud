<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Email extends CI_Controller {

	function Email()
	{
		parent::__construct();
		/*$config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'your host',
    'smtp_port' => 465,
    'smtp_user' => 'your email address',
    'smtp_pass' => 'password',
    'mailtype' => 'html',
    'mailpath' => '/usr/sbin/sendmail',
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE;
    ); 
	$this->load->library('email', $config);
	*/

		$this->load->library('email');
		$this->load->helper('email');
	}
	
	function index()
	{
		//$this->load->view('emailform');
		if($this->input->post('contact'))
		{
		// process data here
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$subject = $this->input->post('subject');
		$message = $this->input->post('message');
		if(empty($name) OR empty($email) OR empty($subject) OR empty($message))
		{
		show_404("The form submitted left fields blank, all fields are required. Please go back and fill in all of the fields.");
		//$this->load->view('emailform');
		}
		$name = $this->security->xss_clean($name);
		$email = $this->security->xss_clean($email);
		$subject = $this->security->xss_clean($subject);
		$message = $this->security->xss_clean($message);
		//########### FOR BATCH EMAIL PROCESSING
		//$config['bcc_batch_mode'] = TRUE;
		//$config['bcc_batch_size'] = 500; // 200 by default
		//$this->email->initialize($config);
		$this->email->from($email, $name);
		$this->email->to('admin@bdcoder26.com');
		$this->email->subject($subject);
		$this->email->message($message);
		if($this->email->send()){
		echo "mail sent";
		$this->load->view('emailform');
		}
else {
echo "error!!!";
}		
		}
		else
		{
		$this->load->view('emailform');
		}
	}	
	
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */
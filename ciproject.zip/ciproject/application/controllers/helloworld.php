<?php
class Helloworld extends CI_Controller{
	function HelloWorld()
	{
	parent::__construct();
	}
	
function _remap($method)
{
echo "you want to run $method method<hr>";	
if($method == "tsp" || $method == "mytsp")
{
	
$this->mytsp();
}
else
{
$this->index();
}
}
	
	
	public function index(){
		echo "hello Round 30. How r u? i am fine. thank you.";		
	}
public function mytsp(){
	echo "<h1>I am from PTTC</h1>";	
}
public function welcome(){
	$this->load->view("header");
	$this->load->view("welcome_message");
	$this->load->view("footer");	
}	
}

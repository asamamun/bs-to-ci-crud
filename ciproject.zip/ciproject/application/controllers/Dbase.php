<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dbase extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->database();
		
	}
	public function index()
	{
		//$this->load->view('welcome_message');
		$result = $this->db->query("select * from blog");
		echo "<h3>As result_array</h3>";
		echo "<h4>Total record found:".$result->num_rows()."</h4>";
		echo "<h4>Total fields found:".$result->num_fields()."</h4>";
			foreach($result->result_array() as $row)
				{
				echo $row['blogtitle']."<br>";
				echo $row['blogcontent'];
				echo "<hr>";
				}
		echo "<h3>As result</h3>";
			foreach($result->result() as $row)
				{
				echo $row->blogtitle."<br>";
				echo $row->blogcontent;
				echo "<hr>";
				}
			$result->free_result();	
	}
	
	function ar(){
		$result = $this->db->get('blog',2,0);
		foreach($result->result() as $row)
				{
				echo $row->blogtitle."<br>";
				echo $row->blogcontent;
				echo "<hr>";
				}
			$result->free_result();	
		
	}
	
		function arwhere(){
			
			
		$result = $this->db->get_where('blog',array('blogid >'=>'3'));
		foreach($result->result() as $row)
				{
				echo $row->blogtitle."<br>";
				echo $row->blogcontent;
				echo "<hr>";
				}
			$result->free_result();	
		
	}
	
			function arselect(){
			
			$this->db->select('blogid,blogtitle');
			$this->db->from('blog');
			$this->db->where('blogid <','10');
		$result = $this->db->get();
		foreach($result->result() as $row)
				{
					echo $row->blogid."<br>";
				echo $row->blogtitle."<br>";
				//echo $row->blogcontent."<br>";
				//echo $row->created."<br>";
				echo "<hr>";
				}
			$result->free_result();	
		
	}
	
	function arlike(){
		$this->db->like('blogcontent','asd');
		$result = $this->db->get('blog');
		foreach($result->result() as $row)
				{
					echo $row->blogid."<br>";
				echo $row->blogtitle."<br>";
				echo $row->blogcontent."<br>";
				//echo $row->created."<br>";
				echo "<hr>";
				}
		
	}
	function argroupby_area(){
		$this->db->select('empid,salediv,saledist,salearea, sum(amount) as sum');
		$this->db->group_by(array('empid', 'salediv', 'saledist','salearea'));
		$result = $this->db->get('sales');
		foreach($result->result() as $row)
				{
					echo $row->empid."<br>";
				echo $row->salediv."<br>";
				echo $row->saledist."<br>";
				echo $row->salearea."<br>";
				echo $row->sum."<br>";
				echo "<hr>";
				}
	}
	
	function argroupby_dist(){
		$this->db->select('empid,salediv,saledist, sum(amount) as sum');
		$this->db->group_by(array('empid', 'salediv', 'saledist'));
		$result = $this->db->get('sales');
		foreach($result->result() as $row)
				{
					echo $row->empid."<br>";
				echo $row->salediv."<br>";
				echo $row->saledist."<br>";
				
				echo $row->sum."<br>";
				echo "<hr>";
				}
	}
		function argroupby_div(){
		$this->db->select('empid,salediv, sum(amount) as sum');
		$this->db->group_by(array('empid', 'salediv'));
		$result = $this->db->get('sales');
		foreach($result->result() as $row)
				{
					echo $row->empid."<br>";
				echo $row->salediv."<br>";				
				
				echo $row->sum."<br>";
				echo "<hr>";
				}
	}
	
	function arinsert(){
		$content = array(
		"blogtitle"=>"খাদিজাকে পেয়ে খুশি সবাই abar",
		"blogcontent"=>"মৃত্যুর মুখ থেকে ফিরে এলেন সিলেটের খাদিজা। তিনি এখন সুস্থ। হাসি-খুশি। কিন্তু বদরুলের কথা শুনেই আঁতকে উঠলেন তিনি। বললেন, ‘আমি ওর সর্বোচ্চ শাস্তি চাই। এমন শাস্তি দেয়া হোক, যা দেখে আর কোনো পাষণ্ড মেয়েদের ওপর নির্মমতা না চালায়।’ খাদিজার পিতা মাসুক মিয়াও জানালেন আইনি লড়াই চালিয়ে যাবেন। খাদিজাকে এখন থেকে আদালতে উপস্থিত করা হবে বলেও জানান তিনি। সিলেটের আদালত খাদিজার জন্য প্রায় দুই মাস ধরে অপেক্ষায়। আলোচিত এ ঘটনায় খাদিজার জবানবন্দি শুনতে চান আদালত। এ কারণে ৩৩ সাক্ষীর সাক্ষ্যগ্রহণের পরও ন্যায় বিচারের স্বার্থে খাদিজার জন্য এ অপেক্ষা।",
		"published"=>"1");
		$this->db->insert("blog",$content);
		echo $this->db->affected_rows();
		
	}
	
	function chaining(){
		$this->db->select('blogid, blogtitle')->from('blog')->
where('blogid >', 30)->limit(40, 0);
$result = $this->db->get();
		foreach($result->result() as $row)
				{
					echo $row->blogid."<br>";
				echo $row->blogtitle."<br>";
				//echo $row->blogcontent."<br>";
				//echo $row->created."<br>";
				echo "<hr>";
				}
		
	}
	
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
function showdate(){
return date("Y-m-d");
}
function showdateandtime(){
return date("Y-m-s H:i:s");
}

function resizeimage($image){
$CI =& get_instance();
$config['image_library'] = 'gd2';
$config['source_image']	= $image;
$config['create_thumb'] = TRUE;
$config['maintain_ratio'] = TRUE;
$config['width']	= 640;
$config['height']	= 480;
$config['rotation_angle'] = 'hor';
$config['x_axis'] = '100';
$config['y_axis'] = '60';

$CI->load->library('image_lib', $config); 

$CI->image_lib->resize();
$CI->image_lib->rotate();
/*if ( ! $CI->image_lib->crop())
{
echo $CI->image_lib->display_errors();
}
else{
return "image cropped!!";
}*/
}
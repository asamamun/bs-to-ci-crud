<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if ( ! function_exists('string_to_array'))
{
	/**
	 * Validate email address
	 *
	 * @deprecated	3.0.0	Use PHP's filter_var() instead
	 * @param	string	$email
	 * @return	bool
	 */
	function string_to_array($string)
	{
		return (array) explode(",",$string) ;
	}
}
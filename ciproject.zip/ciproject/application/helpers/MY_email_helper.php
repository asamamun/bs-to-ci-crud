<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if ( ! function_exists('username'))
{
	/**
	 * Validate email address
	 *
	 * @deprecated	3.0.0	Use PHP's filter_var() instead
	 * @param	string	$email
	 * @return	bool
	 */
	function username($emailaddress)
	{
		return strstr($emailaddress,"@",TRUE);
	}
}

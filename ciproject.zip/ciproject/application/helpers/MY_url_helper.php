<?php
// we are extending url_helper.php in system/helpers
function whereami(){
return __FILE__;
}
<?php
class Blog_model extends CI_Model{
	
	 public function get_last_ten_entries($start,$c)
        {
                $query = $this->db->get('blog', $c, $start);
                return $query->result();
        }
	public function totalblogs(){
		return $this->db->count_all_results('blog');		
	}	
	public function details($id){
		return $this->db->get_where('blog',array('blogid'=>$id))->result();
		}
		
	public function add($blog){
		$this->db->insert("blog",$blog);
		return $this->db->insert_id();
		}
	public function delete($id){
		$this->db->delete('blog', array('blogid' => $id)); 
		}
	public function update($bloginfo){
		$this->db->where('blogid', $bloginfo['blogid']);
		unset($bloginfo['blogid']);
		$this->db->update('blog', $bloginfo); 
		}	 		
	
	}